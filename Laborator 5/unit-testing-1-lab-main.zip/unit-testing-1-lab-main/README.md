# unit-testing-1-lab

<ol>
    
  <li>test_primes: 4p
    <ul>
      <li> Exercise 0: 1p</li>
      <li> Exercise 1: 2p</li>
      <li> Exercise 2: 1p</li>  
    </ul>  
      
  </li>
  
  <li>test_car: 6p  
      
   <ul>
      <li> Exercise 0: 2p</li>
      <li> Exercise 1: 2p</li>
      <li> Exercise 2: 2p</li>  
    </ul>
      
  </li> 
  
</ol>
