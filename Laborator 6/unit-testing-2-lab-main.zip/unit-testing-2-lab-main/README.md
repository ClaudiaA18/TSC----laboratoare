# unit-testing-2-lab

 0. Clobati repo-ul

1. Testati in minim 2 moduri functia is_leap_year, folosind mock.

2. Folosind patch decorator, testati functia get_marks in cazul in care conexiunea da timeout.

3. Folosind patch context manager, implementati functia de teste pentru calculate_total.

4. Creati o baza de date fake ce contine minim 500 de intrari. O intrare este reprezentata de o instanta a clasei Person (pe care trebuie sa o creati) care are minim 3 atribute (nume, varsta, email). Cheia unica este representata de adresa de mail.

5. Creati un stub si o functie fake care sa simuleze functionalitatea metodei get(cheie_unica) pe o baza de date. Puteti sa folositi baza de date creata anterior. 

Link lab: https://ocw.cs.pub.ro/courses/icalc/laboratoare/laborator-06?&#exercitii 
