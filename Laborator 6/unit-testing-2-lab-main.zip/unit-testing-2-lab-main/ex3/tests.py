import unittest
from unittest.mock import patch
import ex3


class TestTotal(unittest.TestCase):
    def test_calculate_total(self):
        return 0

if __name__ == '__main__':
    unittest.main()