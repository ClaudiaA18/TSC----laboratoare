# TODO Creati un stub si o functie fake care sa simuleze 
# functionalitatea metodei get(cheie_unica) pe o baza de date. 
# Puteti sa folositi baza de date creata anterior. 